/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import Dao.AddStudentsDao;
import dto.addStudents;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 *
 * @author HP
 */
@WebServlet(name = "AddStudents", urlPatterns = {"/AddStudents"})
public class AddStudents extends HttpServlet {

   
 

   
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
    }

 
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
         PrintWriter out =  response.getWriter();
        
String enrollment = request.getParameter("enrollment");
String studentName = request.getParameter("student_name");
String email = request.getParameter("email");
String phone = request.getParameter("phone");
String address = request.getParameter("address");
String branch = request.getParameter("branch");
String degree = request.getParameter("degree");
String graduation = request.getParameter("graduation");
String password = request.getParameter("password");

//System.out.println(enrollment + " " + studentName + " " + email +" "+ phone + " "+address + " "+ branch + " "+degree+" "+ graduation+ " "+ password);

addStudents addS = new addStudents();

addS.setEnrollment(enrollment);
addS.setStudentName(studentName);
addS.setEmail(email);
addS.setPhone(phone);
addS.setAddress(address);
addS.setBranch(branch);
addS.setDegree(degree);
addS.setGraduation(graduation);
addS.setPassword(password);
      


AddStudentsDao obj = new AddStudentsDao();
boolean flag = obj.isAddStudents(addS);

if(flag)
{
    out.print("Add Student Successfully");
}
else
{
    out.print("Please Try Again! ");
}

       
    }

   
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
