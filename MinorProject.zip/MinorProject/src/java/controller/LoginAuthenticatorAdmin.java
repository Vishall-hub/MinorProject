/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import db.DBConnector;
import dto.AdminUserDto;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author HP
 */
public class LoginAuthenticatorAdmin {
    
    
    public boolean isLogin(AdminUserDto user)
    {
     
        String id= user.getId();
        String password = user.getPassword();
        String tablePassword="";
        
         try
     {
         String query = "Select password from admin where id = '"+id+"' " ;
     
         Statement st = DBConnector.getStatement();
         ResultSet rs = st.executeQuery(query);
         
         if(rs.next())
         {
             tablePassword = rs.getString(1);
           //  System.out.println(tablePassword);
         }
         else
         {
             return false;
         }
         
     }
     catch(SQLException e)
     {
         System.out.println(e);
     }
     
        if(id!=null && password!=null && !id.trim().equals("") && password.equals(tablePassword))     
        {
            return true;
        }
     
    return false;
    }
        
        
        
   }
    

