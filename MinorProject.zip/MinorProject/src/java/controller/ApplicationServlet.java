package controller;

import db.DBConnector;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import jakarta.servlet.annotation.MultipartConfig;
import java.io.*;
import java.nio.file.*;
import java.sql.*;



public class ApplicationServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Step 1: Get form parameters
        String name = request.getParameter("name");
        String phone = request.getParameter("phone");
        String email = request.getParameter("email");
        String linkedin = request.getParameter("linkedin");
        int companyId = Integer.parseInt(request.getParameter("companyId"));
        int jobId = Integer.parseInt(request.getParameter("jobId"));

        // Step 2: Upload folder path (change if needed)
        String uploadPath = "C:\\Users\\HP\\Documents\\NetBeansProjects\\MinorProject\\uploads";
        File uploadDir = new File(uploadPath);
        if (!uploadDir.exists()) {
            uploadDir.mkdirs();
        }

        // Step 3: Handle file upload
        Part filePart = request.getPart("resume");
        String filePath = null;

        try (PrintWriter out = response.getWriter()) {
            if (filePart != null && filePart.getSize() > 0) {
                String fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();
                fileName = fileName.replaceAll("\\s+", "_");
                filePath = uploadPath + File.separator + fileName;

                saveFile(filePart.getInputStream(), filePath);

                // Step 4: Save application in DB
                boolean success = saveApplication(name, phone, email, linkedin, filePath, companyId, jobId);

                if (success) {
                    out.println("<h3>✅ Application Submitted Successfully!</h3>");
                } else {
                    out.println("<h3>❌ Failed to submit application. Try again.</h3>");
                }
            } else {
                out.println("<h3>❌ Resume file is missing!</h3>");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().write("❌ Error: " + e.getMessage());
        }
    }

    // Saves the uploaded file to disk
    private void saveFile(InputStream fileContent, String filePath) throws IOException {
        Files.copy(fileContent, Paths.get(filePath), StandardCopyOption.REPLACE_EXISTING);
    }

    // Saves application to database
    public boolean saveApplication(String name, String phone, String email, String linkedin,
                                   String filePath, int companyId, int jobId) {

        String query = "INSERT INTO applications (name, phone, email, linkedin, resume_path, company_id, job_id) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DBConnector.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, name);
            pstmt.setString(2, phone);
            pstmt.setString(3, email);
            pstmt.setString(4, linkedin);
            pstmt.setString(5, filePath);
            pstmt.setInt(6, companyId);
            pstmt.setInt(7, jobId);

            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public String getServletInfo() {
        return "Handles job application submissions and file uploads.";
    }
}


