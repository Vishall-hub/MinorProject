/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import dto.CompanyUserDto;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 *
 * @author HP
 */
public class CompanyLogin extends HttpServlet {

 
   
  
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
              response.sendRedirect("login.html");
    }

   
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
   PrintWriter out = response.getWriter();
        
        // Get parameters from the StudentLogin form
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        
        // Debugging print statements
        System.out.println("00");
      
        // Create StudentUserDto object to store user credentials
        CompanyUserDto user = new CompanyUserDto();
        user.setUsername(email);
        user.setPassword(password);

        System.out.print(user.getUsername()   + " 00"); // Check

        // Authenticate the user
        LoginAuthenticatorCompany l2 = new LoginAuthenticatorCompany();
        boolean login = l2.isLogin(user);

       if (login) {
    // If authentication is successful, create a session
    out.print("correct data");

    // Create or retrieve the session
    HttpSession session = request.getSession();  // true creates a new session if none exists
    session.setAttribute("WorkEmail", email);  // Store the username in the session
    
    // Debugging: Print session attribute
    System.out.println("Session attribute 'WorkEmail' set to: " + session.getAttribute("WorkEmail"));

    //Redirect to dashboard
   // RequestDispatcher rd = request.getRequestDispatcher("/dashboard.html");
    //rd.forward(request, response);
    // Redirect to dashboard.html
    out.print("Successfully login ");
    out.println("Welcome "+email);
    response.sendRedirect("CompanyDashboard.html");
} else {
    // If authentication fails, send error message
    
    out.print(email +" "+password);
    out.print("Incorrect data" );
}
    }

   
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
