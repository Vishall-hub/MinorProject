/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import dto.addCompany;
import Dao.AddCompanyDao;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 *
 * @author HP
 */
@WebServlet(name = "AddCompany", urlPatterns = {"/AddCompany"})
public class AddCompany extends HttpServlet {

  
  

    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }

   
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    
        PrintWriter out = response.getWriter();
        
        String Cid = request.getParameter("Cid");
        String Cname = request.getParameter("Cname");
        String Cpassword = request.getParameter("Cpassword");
        String Cdescription = request.getParameter("Cdescription");
        String Cemail = request.getParameter("Cemail");
        
        
        addCompany addC = new addCompany();
        
        addC.setCid(Cid);
        addC.setCname(Cname);
        addC.setCPassword(Cpassword);
        addC.setCdescription(Cdescription);
        addC.setCemail(Cemail);
        
        AddCompanyDao obj = new AddCompanyDao();
        boolean flag = obj.isAddCompany(addC);
        
        if(flag)
        {
            out.print("Company Added Successfully ");
        }
        else
                {
                    out.print("Try Again!");
                }
    
    
    }

  
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
