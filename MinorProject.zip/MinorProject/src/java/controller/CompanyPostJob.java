/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import Dao.JobDao;
import dto.PostJob;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 *
 * @author HP
 */
@WebServlet(name = "CompanyPostJob", urlPatterns = {"/CompanyPostJob"})
public class CompanyPostJob extends HttpServlet {

   
   
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
         PrintWriter out = response.getWriter();
        
String jobTitle = request.getParameter("jobTitle");
String jobType = request.getParameter("jobType");
String location = request.getParameter("location");
String salaryRange = request.getParameter("salary");
String jobDescription = request.getParameter("description");
String requiredSkills = request.getParameter("skills");


//System.out.println(jobTitle + " " + jobType+ " "+ location + " "+ salaryRange + " "+jobDescription + " "+ requiredSkills);
 
    PostJob job = new PostJob();
    
    job.setJobTitle(jobTitle);
    job.setJobType(jobType);
    job.setLocation(location);
    job.setSalaryRange(salaryRange);
    job.setJobDescription(jobDescription);
    job.setRequiredSkills(requiredSkills);
    
    JobDao obj = new JobDao();
    boolean isPostJob = obj.saveJob(job);
    
    
            if(isPostJob)
            {
                out.print(" Job Posted Succesfully ");
            }
            else
            {
                System.err.println("Problem ");
            }
    }
    
    

   
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
