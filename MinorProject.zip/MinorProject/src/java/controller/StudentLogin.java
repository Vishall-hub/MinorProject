package controller;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.RequestDispatcher;

/**
 * 
 * @author HP
 */
public class StudentLogin extends HttpServlet {  // url/pattern in xml file must be same as servletclass name 

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect("login.html");
        
        // You can leave this method empty, or handle any specific GET requests if needed
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        PrintWriter out = response.getWriter();
        
        // Get parameters from the StudentLogin form
        String id = request.getParameter("id");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        
        
        // Debugging print statements
       // System.out.println("0");
      
        // Create StudentUserDto object to store user credentials
        StudentUserDto user = new StudentUserDto();
        user.setUserName(email);
        user.setPassword(password);

       // System.out.print(user.getUserName()   + "00"); // Check

        // Authenticate the user
        LoginAuthenticatorStudent l1 = new LoginAuthenticatorStudent();
        boolean login = l1.isLogin(user);

       if (login) {
    // If authentication is successful, create a session
    out.print("correct data");

    // Create or retrieve the session
    HttpSession session = request.getSession();  // true creates a new session if none exists
    session.setAttribute("userN", email);  // Store the username in the session
    session.setAttribute("Student_id", id);
    // Debugging: Print session attribute
    System.out.println("Session attribute 'userN' set to: " + session.getAttribute("userN"));

    //Redirect to dashboard
   // RequestDispatcher rd = request.getRequestDispatcher("/dashboard.html");
    //rd.forward(request, response);
    // Redirect to dashboard.html
    response.sendRedirect("dashboard.jsp");
} else {
    // If authentication fails, send error message
    
    out.print(email +" "+password);
    out.print("Incorrect data" );
}

    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
}
