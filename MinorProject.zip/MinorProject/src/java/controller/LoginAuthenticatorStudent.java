/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import db.DBConnector;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author HP
 */
class LoginAuthenticatorStudent {
    
    public boolean isLogin(StudentUserDto user)
    {
     String username = user.getUserName();
     String password = user.getPassword();
     String tablePassword="";
     try
     {
         String query = "Select password from students where email= '"+username+"' " ;
     
         Statement st = DBConnector.getStatement();
         ResultSet rs = st.executeQuery(query);
         
         if(rs.next())
         {
             tablePassword = rs.getString(1);
           //  System.out.println(tablePassword);
         }
         else
         {
             return false;
         }
         
     }
     catch(SQLException e)
     {
         System.out.println(e);
     }
     
    if(username!=null && password!=null && !username.trim().equals("") && password.equals(tablePassword))     
        {
            return true;
        }
     
    return false;
    }

   
    
}
