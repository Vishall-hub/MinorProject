package controller;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.PrintWriter;

/**
 * Servlet to check if a user session exists
 */
public class CheckSessionServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        HttpSession session = request.getSession(false); // false = Don't create new session
        boolean isLoggedIn = (session != null && session.getAttribute("userN") != null);

        // JSON Response
        String jsonResponse = "{ \"loggedIn\": " + isLoggedIn + " }";

        PrintWriter out = response.getWriter();
        out.print(jsonResponse);
        out.flush();
    }
}
