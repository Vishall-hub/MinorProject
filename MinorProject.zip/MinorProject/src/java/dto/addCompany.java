/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dto;

/**
 *
 * @author HP
 */
public class addCompany {
    String Cname,CPassword, Cdescription , Cemail, Cid;

    public String getCname() {
        return Cname;
    }

    public void setCname(String Cname) {
        this.Cname = Cname;
    }

    public void setCPassword(String CPassword) {
        this.CPassword = CPassword;
    }

    public void setCdescription(String Cdescription) {
        this.Cdescription = Cdescription;
    }

    public void setCemail(String Cemail) {
        this.Cemail = Cemail;
    }

    public void setCid(String Cid) {
        this.Cid = Cid;
    }

    public String getCPassword() {
        return CPassword;
    }

    public String getCdescription() {
        return Cdescription;
    }

    public String getCemail() {
        return Cemail;
    }

    public String getCid() {
        return Cid;
    }
    
    
}
