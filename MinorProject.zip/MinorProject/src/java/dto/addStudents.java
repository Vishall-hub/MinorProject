/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dto;

/**
 *
 * @author HP
 */
public class addStudents {

    public void setEnrollment(String enrollment) {
        this.enrollment = enrollment;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }

    public void setDegree(String degree) {
        this.degree = degree;
    }

    public void setGraduation(String graduation) {
        this.graduation = graduation;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    String enrollment,studentName,email,phone,address,branch,degree,graduation,password;

    public String getEnrollment() {
        return enrollment;
    }

    public String getStudentName() {
        return studentName;
    }

    public String getEmail() {
        return email;
    }

    public String getPhone() {
        return phone;
    }

    public String getAddress() {
        return address;
    }

    public String getBranch() {
        return branch;
    }

    public String getDegree() {
        return degree;
    }

    public String getGraduation() {
        return graduation;
    }

    public String getPassword() {
        return password;
    }
    
}
