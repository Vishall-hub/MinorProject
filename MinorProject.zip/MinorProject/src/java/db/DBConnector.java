/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import dto.PostJob;
/**
 *
 * @author HP
 */
public class DBConnector {
    
      
    static Connection con = null;
    static Statement st = null;
     
    
    static
    {
        
    try
    {
             Class.forName("com.mysql.cj.jdbc.Driver");
             System.out.println("Driver loaded");

             con = DriverManager.getConnection("jdbc:mysql://localhost:3306/minor","root","root");
             
             st = con.createStatement();
             
              System.out.println("Connection-Statement ");
    }
    catch(ClassNotFoundException | SQLException e)
    {
        System.out.println(e);
    }
     
    }
     
     public static Connection getConnection()
     {
         return con;
     }
       public static Statement getStatement()
    {
        return st;
    }

   
    
}
