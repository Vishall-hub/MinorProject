/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;

import db.DBConnector;
import dto.addStudents;
import java.sql.Connection;
import java.sql.PreparedStatement;

/**
 *
 * @author HP
 */
public class AddStudentsDao {
    
    
    public boolean isAddStudents(addStudents addS)
    {
         boolean status = false;
          try 
          {
            Connection con = DBConnector.getConnection(); 
                
            String query = "INSERT INTO students (enrollment_number, name, email, phone, address, branch, degree, year_of_graduation, password) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

PreparedStatement ps = con.prepareStatement(query);
ps.setString(1, addS.getEnrollment());
ps.setString(2, addS.getStudentName());
ps.setString(3, addS.getEmail());
ps.setString(4, addS.getPhone());
ps.setString(5, addS.getAddress());
ps.setString(6, addS.getBranch());
ps.setString(7, addS.getDegree());
ps.setString(8, addS.getGraduation());
ps.setString(9, addS.getPassword());

int rows = ps.executeUpdate();

status = rows > 0;

                  
                  } catch(Exception e)
                  {
                      e.printStackTrace();
                   }
          return status;
    }
}
    
  