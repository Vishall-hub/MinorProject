/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;

import db.DBConnector;
import dto.addCompany;
import java.sql.Connection;
import java.sql.PreparedStatement;

/**
 *
 * @author HP
 */
public class AddCompanyDao {
    
    boolean status= false;
    
    public boolean isAddCompany(addCompany addC)
    {
         try 
          {
            Connection con = DBConnector.getConnection(); 
                
            String query = "INSERT INTO Companies (id, name, password, description, workemail) VALUES (?, ?, ?, ?, ?)";

PreparedStatement ps = con.prepareStatement(query);
ps.setString(1, addC.getCid());
ps.setString(2, addC.getCname());
ps.setString(3, addC.getCPassword());
ps.setString(4, addC.getCdescription());
ps.setString(5, addC.getCemail());

int rows = ps.executeUpdate();

status = rows > 0;

                  
                  } catch(Exception e)
                  {
                      e.printStackTrace();
                   }
          return status;
        
    }
    
}
