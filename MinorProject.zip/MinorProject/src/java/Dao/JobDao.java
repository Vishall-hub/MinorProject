package Dao;

import db.DBConnector;
import java.sql.Connection;
import java.sql.PreparedStatement;
import dto.PostJob;

public class JobDao { 
    

    public boolean saveJob(PostJob job) {
        boolean status = false;
        int rows;
        
        try (          
            Connection con = DBConnector.getConnection()) {
                
            String query = "INSERT INTO jobs (title, type, location, salary, description, skills) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setString(1, job.getJobTitle());
            ps.setString(2, job.getJobType());
            ps.setString(3, job.getLocation());
            ps.setString(4, job.getSalaryRange());
            ps.setString(5, job.getJobDescription());
            ps.setString(6, job.getRequiredSkills());

           
           rows = ps.executeUpdate();
            status = rows > 0; 

         
        } catch (Exception e) {
            e.printStackTrace();
        }

        return status;
    }
}
